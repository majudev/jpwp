package edu.agh.jpwp;

import java.util.Random;

public class Math {

    public static void main(String[] args) {
        System.out.println("Wyliczanie liczby pi metodą Monte Carlo");

        int iterations = 10000000; // liczba iteracji algorytmu
        int inside = 0; // liczba punktów wewnątrz koła
        Random rand = new Random(); // generator liczb losowych

        // wykonujemy algorytm Monte Carlo
        for (int i = 0; i < iterations; i++) {
            double x = rand.nextDouble();
            double y = rand.nextDouble();
            double dist = java.lang.Math.sqrt(x * x + y * y);
            if (dist < 1.0) {
                inside++;
            }
        }

        // obliczamy przybliżoną wartość liczby pi
        double pi = 4.0 * inside / iterations;

        // wyświetlamy wynik
        System.out.println("Przybliżona wartość liczby pi: " + pi);
    }
}
