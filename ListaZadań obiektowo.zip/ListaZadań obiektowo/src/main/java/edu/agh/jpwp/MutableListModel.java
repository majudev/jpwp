package edu.agh.jpwp;

import javax.swing.*;
import javax.swing.event.ListDataListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MutableListModel implements ListModel<String> {
    private List<String> internalList = new ArrayList<>();

    public MutableListModel(){
    }

    public void sort(){
        Collections.sort(this.internalList);
    }

    public void addElement(String object){
        this.internalList.add(object);
    }

    @Override
    public int getSize() {
        return this.internalList.size();
    }

    @Override
    public String getElementAt(int i) {
        return this.internalList.get(i);
    }

    @Override
    public void addListDataListener(ListDataListener listDataListener) {
    }

    @Override
    public void removeListDataListener(ListDataListener listDataListener) {

    }
}
