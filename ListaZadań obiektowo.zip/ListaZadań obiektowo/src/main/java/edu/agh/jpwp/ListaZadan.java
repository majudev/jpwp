package edu.agh.jpwp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ListaZadan extends JFrame implements ActionListener {

    private JTextField poleTekstowe;
    private JButton przyciskDodaj, przyciskSortuj;
    private JList listaZdan;

    public ListaZadan() {
        super("Lista zdań");

        // Tworzenie elementów interfejsu użytkownika
        poleTekstowe = new JTextField(20);
        przyciskDodaj = new JButton("Dodaj");
        przyciskSortuj = new JButton("Sortuj");
        listaZdan = new JList(new MutableListModel());

        // Dodawanie elementów do panelu
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(poleTekstowe, BorderLayout.WEST);
        panel.add(przyciskDodaj, BorderLayout.CENTER);
        panel.add(przyciskSortuj, BorderLayout.EAST);

        // Dodawanie elementów do ramki
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(listaZdan), BorderLayout.CENTER);

        // Dodawanie akcji dla przycisków
        przyciskDodaj.addActionListener(this);
        przyciskSortuj.addActionListener(this);

        // Konfiguracja ramki
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == przyciskDodaj) {
            String noweZdanie = poleTekstowe.getText();
            if (!noweZdanie.equals("")) {
                MutableListModel model = (MutableListModel) listaZdan.getModel();
                model.addElement(noweZdanie);

                listaZdan.updateUI();
                poleTekstowe.setText("");
            }
        }else if (e.getSource() == przyciskSortuj) {
            MutableListModel model = (MutableListModel) listaZdan.getModel();
            model.sort();

            listaZdan.updateUI();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ListaZadan();
            }
        });
    }
}
