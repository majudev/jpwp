package edu.agh.jpwp;

import java.util.Random;

public class Math {

    public static void main(String[] args) {
        System.out.println("Wyliczanie silni");
        int factorial = 10;
        int result = 1;

        for(int i = 2; i <= factorial; ++i){
            result = result * i;
        }

        System.out.println("Wynik " + factorial + "! = " + result);
    }
}
