package edu.agh.jpwp;

import javax.swing.*;
import javax.swing.event.ListDataListener;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ImmutableListModel implements ListModel<String> {
    private final List<String> internalList;

    public ImmutableListModel(){
        this.internalList = new ArrayList<String>();
    }

    public ImmutableListModel(final List<String> list){
        this.internalList = list;
    }

    public ImmutableListModel(final ImmutableListModel old, final String object){
        //this.internalList = ArrayList<E>(old.internalList, Collections.singletonList(object));
        this.internalList = (List<String>) Stream.of(old.internalList, Collections.singletonList(object)).flatMap(Collection::stream).collect(Collectors.toList());
        //this.internalList = (List<E>) Stream.concat(old.internalList.stream(), Collections.singletonList(object).stream()).collect(Collectors.toList());
    }

    @Override
    public int getSize() {
        return this.internalList.size();
    }

    @Override
    public String getElementAt(int i) {
        return this.internalList.get(i);
    }

    public final ImmutableListModel sort(){
        /**
         * Niestety sortowanie w Javie wymaga użycia wzorca
         * niezgodnego z programowaniem funkcyjnym. Udajemy
         * że nic się nie stało poprzez stworzenie nowego
         * obiektu, na którym wykonamy operację.
         */
        final List<String> newList = this.internalList;
        Collections.sort(newList);
        return new ImmutableListModel(newList);
    }

    @Override
    public void addListDataListener(ListDataListener listDataListener) {

    }

    @Override
    public void removeListDataListener(ListDataListener listDataListener) {

    }
}
