package edu.agh.jpwp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ListaZadan extends JFrame implements ActionListener {
    private final JTextField poleTekstowe;
    private final JButton przyciskDodaj, przyciskSortuj;
    private final JList listaZdan;

    public ListaZadan() {
        super("Lista zdań");

        // Tworzenie elementów interfejsu użytkownika
        poleTekstowe = new JTextField(20);
        przyciskDodaj = new JButton("Dodaj");
        przyciskSortuj = new JButton("Sortuj");
        /**
         * Pierwsza zmiana: inicjujemy JList pustym modelem
         */
        listaZdan = new JList(new ImmutableListModel());

        // Dodawanie elementów do panelu
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(poleTekstowe, BorderLayout.WEST);
        panel.add(przyciskDodaj, BorderLayout.CENTER);
        panel.add(przyciskSortuj, BorderLayout.EAST);

        // Dodawanie elementów do ramki
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(listaZdan), BorderLayout.CENTER);

        // Dodawanie akcji dla przycisków
        przyciskDodaj.addActionListener(this);
        przyciskSortuj.addActionListener(this);

        // Konfiguracja ramki
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == przyciskDodaj) {
            final String noweZdanie = poleTekstowe.getText();
            if (!noweZdanie.equals("")) {
                /**
                 * Ważna zmiana!
                 * Teraz nasza lista jest immutable
                 */
                final ImmutableListModel stary_model = (ImmutableListModel) listaZdan.getModel();
                final ImmutableListModel nowy_model = new ImmutableListModel(stary_model, noweZdanie);
                listaZdan.setModel(nowy_model);

                listaZdan.updateUI();
                poleTekstowe.setText("");
            }
        }else if (e.getSource() == przyciskSortuj) {
            /**
             * Ważna zmiana!
             * Teraz nasza lista jest immutable
             */
            final ImmutableListModel stary_model = (ImmutableListModel) listaZdan.getModel();
            final ImmutableListModel nowy_model = stary_model.sort();
            listaZdan.setModel(nowy_model);

            listaZdan.updateUI();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ListaZadan();
            }
        });
    }
}
